
#include "bme_support.h"
#include "stm32f4xx_hal.h"
#include <stdlib.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#define BME_ADDR (0x76<<1)




/*!
 * @brief This API reads the sensor temperature, pressure and humidity data in forced mode.
 */
int8_t stream_sensor_data_forced_mode(struct bme280_dev *dev) {
	/* Variable to define the result */
	int8_t rslt = BME280_OK;

	/* Variable to define the selecting sensors */
	uint8_t settings_sel = 0;

	/* Variable to store minimum wait time between consecutive measurement in force mode */
	uint32_t req_delay;

	/* Structure to get the pressure, temperature and humidity values */
	struct bme280_data comp_data;

	//uint16_t tx_buffer = 0;
	char tx_buffer[50];
	struct handle *uart = (struct handle *)dev->intf_ptr;

	/* Recommended mode of operation: Indoor navigation */
	dev->settings.osr_h = BME280_OVERSAMPLING_1X;
	dev->settings.osr_p = BME280_OVERSAMPLING_16X;
	dev->settings.osr_t = BME280_OVERSAMPLING_2X;
	dev->settings.filter = BME280_FILTER_COEFF_16;

	settings_sel = BME280_OSR_PRESS_SEL | BME280_OSR_TEMP_SEL
			| BME280_OSR_HUM_SEL | BME280_FILTER_SEL;

	/* Set the sensor settings */
	rslt = bme280_set_sensor_settings(settings_sel, dev);
	if (rslt != BME280_OK) {
		//fprintf(stderr, "Failed to set sensor settings (code %+d).", rslt);
		HAL_UART_Transmit(&(*(uart->uart)), (uint8_t*) tx_buffer,
				sprintf(tx_buffer, "Failed to set sensor settings (code %+d).\n\r", rslt), 500);

		return rslt;
	}

	//printf("Temperature, Pressure, Humidity\n");
	HAL_UART_Transmit(&(*(uart->uart)), (uint8_t*) tx_buffer,
			sprintf(tx_buffer, "Temperature, Pressure, Humidity\n\r"), 500);

	/*Calculate the minimum delay required between consecutive measurement based upon the sensor enabled
	 *  and the oversampling configuration. */
	req_delay = bme280_cal_meas_delay(&dev->settings);

	/* Continuously stream sensor data */
	while (1) {
		/* Set the sensor to forced mode */
		rslt = bme280_set_sensor_mode(BME280_FORCED_MODE, dev);
		if (rslt != BME280_OK) {
			//fprintf(stderr, "Failed to set sensor mode (code %+d).", rslt);
			HAL_UART_Transmit(&(*(uart->uart)), (uint8_t*) tx_buffer,
					sprintf(tx_buffer,
							"Failed to set sensor mode (code %+d).\n\r", rslt),
					500);
			break;
		}

		/* Wait for the measurement to complete and print data */
		dev->delay_us(req_delay, dev->intf_ptr);
		rslt = bme280_get_sensor_data(BME280_ALL, &comp_data, dev);
		if (rslt != BME280_OK) {
			//fprintf(stderr, "Failed to get sensor data (code %+d).", rslt);
			HAL_UART_Transmit(&(*(uart->uart)), (uint8_t*) tx_buffer,
					sprintf(tx_buffer,
							"Failed to get sensor data (code %+d).\n\r", rslt),
					500);
			break;
		}

		print_sensor_data(&comp_data, (uart->uart));


	}

	return rslt;
}

void print_sensor_data(struct bme280_data *comp_data, UART_HandleTypeDef *uart) {

	float temp, press, hum;
	char tx_buffer[50];

#ifdef BME280_FLOAT_ENABLE
  	      temp = comp_data->temperature;
  	      press = 0.01 * comp_data->pressure;
  	      hum = comp_data->humidity;
  	  #else
#ifdef BME280_64BIT_ENABLE
  	      temp = 0.01f * comp_data->temperature;
  	      press = 0.0001f * comp_data->pressure;
  	      hum = 1.0f / 1024.0f * comp_data->humidity;
  	  #else
	temp = 0.01f * comp_data->temperature;
	press = 0.01f * comp_data->pressure;
	hum = 1.0f / 1024.0f * comp_data->humidity;
#endif
#endif
	HAL_UART_Transmit(uart, (uint8_t*) tx_buffer,
						sprintf(tx_buffer, "%0.2lf deg C, %0.2lf hPa, %0.2lf%%\n\r", temp,
								press, hum), 500);


}

int8_t stream_sensor_data_normal_mode(struct bme280_dev *dev) {
	int8_t rslt;
	uint8_t settings_sel;
	struct bme280_data comp_data;
	//uint16_t tx_buffer;
	struct handle *uart = (struct handle *)dev->intf_ptr;

	/* Recommended mode of operation: Indoor navigation */
	dev->settings.osr_h = BME280_OVERSAMPLING_1X;
	dev->settings.osr_p = BME280_OVERSAMPLING_16X;
	dev->settings.osr_t = BME280_OVERSAMPLING_2X;
	dev->settings.filter = BME280_FILTER_COEFF_16;
	dev->settings.standby_time = BME280_STANDBY_TIME_62_5_MS;

	settings_sel = BME280_OSR_PRESS_SEL;
	settings_sel |= BME280_OSR_TEMP_SEL;
	settings_sel |= BME280_OSR_HUM_SEL;
	settings_sel |= BME280_STANDBY_SEL;
	settings_sel |= BME280_FILTER_SEL;
	rslt = bme280_set_sensor_settings(settings_sel, dev);
	rslt = bme280_set_sensor_mode(BME280_NORMAL_MODE, dev);

	printf("Temperature, Pressure, Humidity\r\n");
	while (1) {
		/* Delay while the sensor completes a measurement */
		dev->delay_us(70, dev->intf_ptr);
		rslt = bme280_get_sensor_data(BME280_ALL, &comp_data, dev);
		print_sensor_data(&comp_data, uart->uart);
	}

	return rslt;
}
int8_t user_i2c_read(uint8_t reg_addr, uint8_t *reg_data, uint32_t len, void *intf_ptr)
  {
      int8_t rslt = 0; /* Return 0 for Success, non-zero for failure */
      HAL_StatusTypeDef status = HAL_OK;

      /*
       * The parameter intf_ptr can be used as a variable to store the I2C address of the device
       */

      /*
       * Data on the bus should be like
       * |------------+---------------------|
       * | I2C action | Data                |
       * |------------+---------------------|
       * | Start      | -                   |
       * | Write      | (reg_addr)          |
       * | Stop       | -                   |
       * | Start      | -                   |
       * | Read       | (reg_data[0])       |
       * | Read       | (....)              |
       * | Read       | (reg_data[len - 1]) |
       * | Stop       | -                   |
       * |------------+---------------------|
       */
      struct handle* i2c = (struct handle *)(intf_ptr);
      status = HAL_I2C_Master_Transmit(i2c->i2c,BME_ADDR, &reg_addr,1,100);
      status = HAL_I2C_Master_Receive(i2c->i2c, BME_ADDR, reg_data, len, 100);
      if (status != HAL_OK) {
    	  rslt = 1; // Error
      }
      return rslt;
  }

  int8_t user_i2c_write(uint8_t reg_addr, const uint8_t *reg_data, uint32_t len, void *intf_ptr)
  {
      int8_t rslt = 0; /* Return 0 for Success, non-zero for failure */
      //HAL_StatusTypeDef status = HAL_OK;


      /*
       * The parameter intf_ptr can be used as a variable to store the I2C address of the device
       */

      /*
       * Data on the bus should be like
       * |------------+---------------------|
       * | I2C action | Data                |
       * |------------+---------------------|
       * | Start      | -                   |
       * | Write      | (reg_addr)          |
       * | Write      | (reg_data[0])       |
       * | Write      | (....)              |
       * | Write      | (reg_data[len - 1]) |
       * | Stop       | -                   |
       * |------------+---------------------|
       */

      uint8_t *buf;


      buf = malloc(len + 1);
      buf[0] = reg_addr;
      memcpy(buf + 1, reg_data, len);
      struct handle *i2c = (struct handle *)intf_ptr;
      HAL_I2C_Master_Transmit((i2c->i2c),BME_ADDR, buf,len + 1,100);


      free(buf);

      return BME280_OK;


      return rslt;
  }

void delay_us(uint32_t us, void *intf_ptr) {
  	HAL_Delay(us);
  }
