#ifndef BME_SUPPORT_H_
#define BME_SUPPORT_H_

#include "bme280.h"
#include "bme280_defs.h"


struct handle
{
	/*** Added for passing the i2c and uart structs ***/
	I2C_HandleTypeDef* i2c;
	UART_HandleTypeDef* uart;
	uint8_t dev_addr;
	void* sdata;
};



int8_t user_i2c_read(uint8_t reg_addr, uint8_t *reg_data, uint32_t len, void *intf_ptr);
int8_t user_i2c_write(uint8_t reg_addr, const uint8_t *reg_data, uint32_t len, void *intf_ptr);
void delay_us(uint32_t us, void *intf_ptr);
void print_sensor_data(struct bme280_data *comp_data, UART_HandleTypeDef *uart);
int8_t stream_sensor_data_normal_mode(struct bme280_dev *dev);
int8_t stream_sensor_data_forced_mode(struct bme280_dev *dev);

#endif /* BME_SUPPORT_H_ */
